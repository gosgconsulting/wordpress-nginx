<?php

namespace FluentMail\App\Services\DB\QueryBuilder;

class TransactionHaltException extends \Exception
{
}
