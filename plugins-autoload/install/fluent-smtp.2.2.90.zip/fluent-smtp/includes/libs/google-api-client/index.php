<?php // silence is golden


/**
 *
 * Remove the build folder
 * run composer install --no-dev
 * That's it
 */
