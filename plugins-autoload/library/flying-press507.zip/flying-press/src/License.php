<?php

namespace FlyingPress;

class License
{
  private static $surecart_key = 'pt_ZFDsoFWUW6hPMLqpQskUYDcz';
  private static $client;
  private static $hardcoded_license_key = 'B5E0B5F8DD8689E6ACA49DD6E6E1A930';

  public static function init()
  {
    // Load licensing SDK
    add_action('init', [__CLASS__, 'load_sdk']);

    // Auto-activate license on init
    add_action('init', [__CLASS__, 'auto_activate_license']);

    // Check if license key is set
    add_action('admin_notices', [__CLASS__, 'license_notice']);

    // License check every week (disabled for bypass)
    // add_action('flying_press_license_reactivation', [__CLASS__, 'update_license_status']);
    // if (!wp_next_scheduled('flying_press_license_reactivation')) {
    //   wp_schedule_event(time(), 'weekly', 'flying_press_license_reactivation');
    // }

    // Activate license on plugin activation
    register_activation_hook(FLYING_PRESS_FILE_NAME, [__CLASS__, 'activate_license']);

    // Check activation after upgrade
    add_action('flying_press_upgraded', [__CLASS__, 'check_activation']);
  }

  public static function auto_activate_license()
  {
    $config = Config::$config;

    // If license is not already active, activate it automatically
    if (!$config['license_active'] || !$config['license_key']) {
      Config::update_config([
        'license_key' => self::$hardcoded_license_key,
        'license_active' => true,
        'license_status' => 'active',
      ]);
    }
  }

  public static function load_sdk()
  {
    // Initialize the SureCart client
    if (!class_exists('SureCart\Licensing\Client')) {
      require_once FLYING_PRESS_PLUGIN_DIR . 'licensing/src/Client.php';
    }

    self::$client = new \SureCart\Licensing\Client(
      'FlyingPress',
      self::$surecart_key,
      FLYING_PRESS_FILE
    );
  }

  public static function activate_license($license_key = null)
  {
    // Use hardcoded license key if none provided
    if (!$license_key) {
      $license_key = self::$hardcoded_license_key;
    }

    // Always return success for our hardcoded key or any key
    Config::update_config([
      'license_key' => $license_key,
      'license_active' => true,
      'license_status' => 'active',
    ]);

    return true;
  }

  public static function check_activation()
  {
    $config = Config::$config;

    // Always ensure license is active
    if (!$config['license_active'] || !$config['license_key']) {
      self::activate_license();
    }
  }

  public static function update_license_status()
  {
    // Bypass external API call - always keep status as active
    Config::update_config([
      'license_status' => 'active',
    ]);
  }

  public static function license_notice()
  {
    // Don't show notice on FlyingPress page
    if (isset($_GET['page']) && $_GET['page'] === 'flying-press') {
      return;
    }

    $config = Config::$config;

    // Always consider license as active for bypass
    if (!$config['license_active']) {
      // Force activate if somehow not active
      self::activate_license();
      return;
    }

    // No notices needed - license is always valid
  }
}
