<?php

namespace FlyingPress;

class RestApi
{
  public static function init()
  {
    add_action('rest_api_init', [__CLASS__, 'register_rest_apis']);
    add_action('rest_api_init', [__CLASS__, 'register_public_rest_apis']);
  }

  public static function register_public_rest_apis()
  {
    // Public license validation endpoint (no auth required)
    register_rest_route('flying-press', '/validate-license/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'validate_license_public'],
      'permission_callback' => '__return_true',
    ]);
  }

  public static function register_rest_apis()
  {
    // Only allow access to the REST API for users with the specified roles
    if (!Auth::is_allowed()) {
      return;
    }

    register_rest_route('flying-press', '/cache_status/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'get_cache_status'],
      'permission_callback' => '__return_true',
    ]);

    register_rest_route('flying-press', '/config/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'update_config'],
      'permission_callback' => '__return_true',
    ]);

    register_rest_route('flying-press', '/purge-current-page/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'purge_current_page'],
      'permission_callback' => '__return_true',
    ]);

    register_rest_route('flying-press', '/preload-cache/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'preload_cache'],
      'permission_callback' => '__return_true',
    ]);

    register_rest_route('flying-press', '/purge-pages-and-preload/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'purge_pages_and_preload'],
      'permission_callback' => '__return_true',
    ]);

    register_rest_route('flying-press', '/purge-everything/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'purge_everything'],
      'permission_callback' => '__return_true',
    ]);

    register_rest_route('flying-press', '/activate-license/', [
      'methods' => 'POST',
      'callback' => [__CLASS__, 'activate_license'],
      'permission_callback' => '__return_true',
    ]);
  }

  public static function validate_license_public($request)
  {
    // Always return valid license for any key
    return [
      'valid' => true,
      'license' => [
        'key' => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
        'status' => 'active',
        'activations' => 1,
        'limit' => 5
      ]
    ];
  }

  public static function get_cache_status()
  {
    return [
      'pages_cached' => Caching::count_pages(FLYING_PRESS_CACHE_DIR),
      'pages_in_queue' => Preload::$worker->get_remaining_tasks_count(),
    ];
  }

  public static function update_config($request)
  {
    $config = $request->get_json_params();

    if (empty($config)) {
      return new \WP_Error('flying-press/invalid-config', 'Invalid config');
    }

    Config::update_config($config);
    return Config::$config;
  }

  public static function preload_cache()
  {
    Preload::preload_cache();
    return ['success' => true];
  }

  public static function purge_current_page($request)
  {
    function_exists('fastcgi_finish_request') && fastcgi_finish_request();
    $url = $request->get_param('url');

    if (empty($url)) {
      return new \WP_Error('flying-press/invalid-url', 'Invalid URL');
    }

    Purge::purge_urls([$url]);
    Preload::preload_urls([$url]);
    return ['success' => true];
  }

  public static function purge_pages_and_preload()
  {
    Purge::purge_pages();
    Preload::preload_cache();
    return ['success' => true];
  }

  public static function purge_everything()
  {
    Purge::purge_everything();
    return ['success' => true];
  }

  public static function activate_license($request)
  {
    $license_key = $request->get_param('license_key');

    // Always return success regardless of the key provided
    if (empty($license_key)) {
      $license_key = 'B5E0B5F8DD8689E6ACA49DD6E6E1A930';
    }

    try {
      // Force license activation to always succeed
      Config::update_config([
        'license_key' => $license_key,
        'license_active' => true,
        'license_status' => 'active',
      ]);

      return Config::$config;
    } catch (\Exception $e) {
      // Even if there's an exception, force success
      Config::update_config([
        'license_key' => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
        'license_active' => true,
        'license_status' => 'active',
      ]);

      return Config::$config;
    }
  }
}
