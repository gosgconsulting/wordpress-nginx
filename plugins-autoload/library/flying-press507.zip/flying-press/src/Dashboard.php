<?php

namespace FlyingPress;

class Dashboard
{
  public static $menu_icon = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjYiIGhlaWdodD0iMTciIHZpZXdCb3g9IjAgMCAyNiAxNyIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTExLjA1OTQgMEM5LjYzODc0IDAgOC4zMTQ5NiAwLjcxODcwNyA3LjU0MDQ4IDEuOTEwMDRMNS41NTUxNSA0Ljk2NTQxTDAgMTMuNTI5OUgxLjY2ODE1QzIuNjA4NTMgMTMuNTI5OSAzLjQ4NDc4IDEzLjA1MzEgMy45OTU3NSAxMi4yNjMzTDcuMzEzMjMgNy4xNjE5NkM4LjE5OTI0IDUuNzkyMTcgOS43MTg5MSA0Ljk2NTQxIDExLjM0OTQgNC45NjU0MUgyMC4yNzk5QzIxLjcwMDYgNC45NjU0MSAyMy4wMjQ0IDQuMjQ2NzEgMjMuNzk4OCAzLjA1NTM3TDI1Ljc4NDIgMEgxMS4wNTk0WiIgZmlsbD0iIzRGNDZFNSIvPgo8cGF0aCBkPSJNMTIuMDY0NiA2LjU3ODEyQzEwLjY0MzkgNi41NzgxMiA5LjMxOTQ1IDcuMjk2ODMgOC41NDQ5NyA4LjQ4ODE2TDguNTIxMjcgOC41MjQ0MUw4LjA5NzQ0IDkuMTc2OUw2LjU1OTY1IDExLjU0MzVINi41NjAzNEwzLjQyOTY5IDE2LjM2NEg1LjExMTc4QzYuMDQzOCAxNi4zNjQgNi45MTIzOCAxNS44OTI3IDcuNDE5ODYgMTUuMTExM0w5LjA2NTcxIDEyLjU3OEM5LjQ4NDY2IDExLjkzMjUgMTAuMjAyIDExLjU0MzUgMTAuOTcxNiAxMS41NDM1SDE3LjA1NjVDMTguNDc3MiAxMS41NDM1IDE5LjgwMSAxMC44MjQ4IDIwLjU3NTUgOS42MzM1TDIyLjU2MDggNi41NzgxMkgxMi4wNjQ2WiIgZmlsbD0iIzRGNDZFNSIvPgo8L3N2Zz4K';

  public static function init()
  {
    add_action('admin_menu', [__CLASS__, 'add_menu']);
  }

  public static function add_menu()
  {
    if (!Auth::is_allowed()) {
      return;
    }

    $menu = add_menu_page(
      'FlyingPress',
      'FlyingPress',
      'edit_posts',
      'flying-press',
      [__CLASS__, 'render'],
      self::$menu_icon,
      '81'
    );

    // A kind of hack to inject JS only in the page we need
    add_action('admin_print_scripts-' . $menu, [__CLASS__, 'add_js']);
  }

  public static function add_js()
  {
    wp_enqueue_script(
      'flying_press_dashboard',
      FLYING_PRESS_PLUGIN_URL . 'assets/app.js',
      [],
      filemtime(FLYING_PRESS_PLUGIN_DIR . 'assets/app.js'),
      true
    );
  }

  public static function render()
  {
    // Ensure license is active in config before rendering
    Config::force_license_active();

    $config = json_encode(Config::$config);
    $version = FLYING_PRESS_VERSION;
    echo "<script>window.flying_press={config:$config,version:'$version'}</script>";

    // Add comprehensive JavaScript to intercept all license validation attempts
    echo "<script>
    (function() {
        // Store original fetch
        const originalFetch = window.fetch;

        // Override fetch to intercept license validation calls
        window.fetch = function(url, options) {
            if (typeof url === 'string') {
                // Intercept license validation calls
                if (url.includes('license.flyingpress.com') ||
                    url.includes('api.surecart.com') ||
                    url.includes('/validate') ||
                    url.includes('license')) {

                    console.log('Intercepted license call:', url);

                    return Promise.resolve({
                        ok: true,
                        status: 200,
                        statusText: 'OK',
                        headers: new Headers({'content-type': 'application/json'}),
                        json: () => Promise.resolve({
                            valid: true,
                            license: {
                                key: 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
                                status: 'active',
                                activations: 1,
                                limit: 5
                            }
                        }),
                        text: () => Promise.resolve(JSON.stringify({
                            valid: true,
                            license: {
                                key: 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
                                status: 'active',
                                activations: 1,
                                limit: 5
                            }
                        }))
                    });
                }
            }

            // For all other requests, use original fetch
            return originalFetch.apply(this, arguments);
        };

        // Store original XMLHttpRequest
        const OriginalXMLHttpRequest = window.XMLHttpRequest;

        // Override XMLHttpRequest to intercept license calls
        window.XMLHttpRequest = function() {
            const xhr = new OriginalXMLHttpRequest();
            const originalOpen = xhr.open;
            const originalSend = xhr.send;

            xhr.open = function(method, url, ...args) {
                this._url = url;
                return originalOpen.apply(this, [method, url, ...args]);
            };

            xhr.send = function(data) {
                if (this._url && (
                    this._url.includes('license.flyingpress.com') ||
                    this._url.includes('api.surecart.com') ||
                    this._url.includes('/validate') ||
                    this._url.includes('license'))) {

                    console.log('Intercepted XHR license call:', this._url);

                    // Simulate successful response
                    setTimeout(() => {
                        Object.defineProperty(this, 'status', { value: 200, writable: false });
                        Object.defineProperty(this, 'statusText', { value: 'OK', writable: false });
                        Object.defineProperty(this, 'readyState', { value: 4, writable: false });
                        Object.defineProperty(this, 'responseText', {
                            value: JSON.stringify({
                                valid: true,
                                license: {
                                    key: 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
                                    status: 'active',
                                    activations: 1,
                                    limit: 5
                                }
                            }),
                            writable: false
                        });

                        if (this.onreadystatechange) {
                            this.onreadystatechange();
                        }
                        if (this.onload) {
                            this.onload();
                        }
                    }, 10);

                    return;
                }

                return originalSend.apply(this, arguments);
            };

            return xhr;
        };

        // Copy static properties
        Object.setPrototypeOf(window.XMLHttpRequest, OriginalXMLHttpRequest);
        Object.defineProperties(window.XMLHttpRequest, Object.getOwnPropertyDescriptors(OriginalXMLHttpRequest));

        console.log('FlyingPress license bypass initialized');
    })();
    </script>";

    // Add CSS for license activation styling
    echo "<style>
    .license-activated {
        color: #28a745 !important;
        background-color: #d4edda !important;
        border-color: #c3e6cb !important;
    }

    .license-status {
        display: inline-block;
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
        font-weight: 500;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 0.25rem;
    }

    .license-status.active {
        color: #155724;
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
    }
    </style>";

    echo '<div id="app"></div>';
  }
}
