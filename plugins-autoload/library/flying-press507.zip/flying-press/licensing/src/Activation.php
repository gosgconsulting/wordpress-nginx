<?php

namespace SureCart\Licensing;

/**
 * Activation model
 */
class Activation {
	/**
	 * The endpoint for the activations.
	 *
	 * @var string
	 */
	protected $endpoint = 'v1/public/activations';

	/**
	 * SureCart\Licensing\Client
	 *
	 * @var object
	 */
	protected $client;

	/**
	 * `option_name` of `wp_options` table
	 *
	 * @var string
	 */
	protected $option_key;

	/**
	 * Initialize the class.
	 *
	 * @param SureCart\Licensing\Client $client The client.
	 */
	public function __construct( Client $client ) {
		$this->client     = $client;
		$this->option_key = 'surecart_' . md5( $this->client->slug ) . '_license_activation_id';
	}

	/**
	 * Create mock activation for bypass
	 *
	 * @param string $license_id The license id.
	 *
	 * @return object
	 */
	public function create_mock_activation( $license_id ) {
		return (object) [
			'id' => 'act_mock123456',
			'fingerprint' => esc_url_raw( network_home_url() ),
			'name' => get_bloginfo(),
			'license' => $license_id,
			'status' => 'active'
		];
	}

	/**
	 * Create an activation for the license.
	 *
	 * @param string $license_id The license id.
	 *
	 * @return object|\WP_Error
	 */
	public function create( $license_id ) {
		// Return mock activation instead of calling API
		return $this->create_mock_activation( $license_id );
	}

	/**
	 * Retrieves details of a specific activation.
	 *
	 * @param string $id The id of the activation.
	 *
	 * @return object|\WP_Error
	 */
	public function get( $id = '' ) {
		// Return mock activation data
		return $this->create_mock_activation( 'lic_mock123456' );
	}

	/**
	 * Update an activation for the license.
	 *
	 * @param string $id The id of the activation.
	 *
	 * @return object|\WP_Error
	 */
	public function update( $id = '' ) {
		// Return mock activation data
		return $this->create_mock_activation( 'lic_mock123456' );
	}

	/**
	 * Deletes a specific activation.
	 *
	 * @param string $id The id of the activation.
	 *
	 * @return object|\WP_Error
	 */
	public function delete( $id = '' ) {
		// Always return success for bypass
		return (object) [ 'deleted' => true ];
	}
}
