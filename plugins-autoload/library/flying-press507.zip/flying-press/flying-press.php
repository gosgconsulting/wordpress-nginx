<?php

/**
 * Plugin Name: FlyingPress
 * Plugin URI: https://flyingpress.com
 * Description: Lightning-Fast WordPress on Autopilot
 * Version: 5.0.7
 * Requires PHP: 7.4
 * Requires at least: 4.7
 * Author: FlyingWeb
 */

defined('ABSPATH') or die('No script kiddies please!');

require_once dirname(__FILE__) . '/vendor/autoload.php';

define('FLYING_PRESS_VERSION', '5.0.7');
define('FLYING_PRESS_FILE', __FILE__);
define('FLYING_PRESS_FILE_NAME', plugin_basename(__FILE__));
define('FLYING_PRESS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FLYING_PRESS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FLYING_PRESS_CACHE_DIR', WP_CONTENT_DIR . '/cache/flying-press/');
define('FLYING_PRESS_CACHE_URL', WP_CONTENT_URL . '/cache/flying-press/');

!is_dir(FLYING_PRESS_CACHE_DIR) && mkdir(FLYING_PRESS_CACHE_DIR, 0755, true);

// Add comprehensive HTTP request filter to intercept external API calls
add_filter('pre_http_request', function($preempt, $parsed_args, $url) {
    // Intercept page optimizer calls
    if (strpos($url, 'page-optimizer.flyingpress.com/optimizer/') !== false) {
        return array(
            'body' => json_encode(array(
                'css_used' => array('used' => '', 'unused' => ''),
                'css_critical' => '',
                'js_delay' => array(),
                'html' => $parsed_args['body']['html'] ?? '',
                'optimized' => true
            )),
            'response' => array('code' => 200, 'message' => 'OK'),
            'headers' => array('content-type' => 'application/json')
        );
    }

    // Intercept SureCart license API calls
    if (strpos($url, 'api.surecart.com') !== false) {
        if (strpos($url, '/v1/public/licenses/') !== false) {
            // License validation calls
            return array(
                'body' => json_encode(array(
                    'id' => 'lic_mock123456',
                    'key' => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
                    'status' => 'active',
                    'activations_count' => 1,
                    'activations_limit' => 5
                )),
                'response' => array('code' => 200, 'message' => 'OK'),
                'headers' => array('content-type' => 'application/json')
            );
        }

        if (strpos($url, '/v1/public/activations') !== false) {
            // Activation calls
            return array(
                'body' => json_encode(array(
                    'id' => 'act_mock123456',
                    'fingerprint' => home_url(),
                    'name' => get_bloginfo('name'),
                    'license' => 'lic_mock123456',
                    'status' => 'active'
                )),
                'response' => array('code' => 200, 'message' => 'OK'),
                'headers' => array('content-type' => 'application/json')
            );
        }
    }

    // Intercept FlyingPress license validation calls
    if (strpos($url, 'license.flyingpress.com') !== false) {
        return array(
            'body' => json_encode(array(
                'valid' => true,
                'license' => array(
                    'key' => 'B5E0B5F8DD8689E6ACA49DD6E6E1A930',
                    'status' => 'active',
                    'activations' => 1,
                    'limit' => 5
                )
            )),
            'response' => array('code' => 200, 'message' => 'OK'),
            'headers' => array('content-type' => 'application/json')
        );
    }

    return $preempt;
}, 10, 3);

FlyingPress\WPCache::init();
FlyingPress\Htaccess::init();
FlyingPress\AdvancedCache::init();
FlyingPress\Integrations::init();
FlyingPress\AutoPurge::init();
FlyingPress\License::init();
FlyingPress\Preload::init();
FlyingPress\Config::init();
FlyingPress\Cron::init();
FlyingPress\Caching::init();
FlyingPress\RestApi::init();
FlyingPress\AdminBar::init();
FlyingPress\Optimizer::init();
FlyingPress\FlyingCDN::init();
FlyingPress\Dashboard::init();
FlyingPress\Database::init();
FlyingPress\Compatibility::init();
FlyingPress\Permalink::init();
FlyingPress\Shortcuts::init();
FlyingPress\WpCLI::init();
